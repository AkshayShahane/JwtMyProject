package com.practice.jwt.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.practice.jwt.model.User;
import com.practice.jwt.repositories.UserRepository;
import com.practice.jwt.service.IUserService;

@Service
public class UserServiceImpl implements IUserService, UserDetailsService {

	@Autowired
	UserRepository repository;

	@Autowired
	BCryptPasswordEncoder bcryptPwdEncoder;

	@Override
	public String createUser(User user) {
		user.setPassword(bcryptPwdEncoder.encode(user.getPassword()));
		User registeredUser = repository.save(user);
		return "User is created with User Id : " + registeredUser.getId();
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> optUsername = findByUserName(username);
		if (optUsername.isEmpty()) {
			throw new UsernameNotFoundException("Record is not found for given username");
		}
		User usr = optUsername.get();
		return new org.springframework.security.core.userdetails.User(username, usr.getPassword(),
				usr.getRoles().stream().map(role -> new SimpleGrantedAuthority(role)).collect(Collectors.toList()));
	}

	@Override
	public Optional<User> findByUserName(String username) {
		return repository.findByUserName(username);
	}

	@Override
	public List<User> getUsers() {
		return repository.findAll();
	}

}
