package com.practice.jwt.util;

import java.util.Base64;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.util.StringBuilderFormattable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {
	
	@Value("${api.secret}")
	private String secretKey;

	//1.generate token
	public String generateToken(String subject) {
		String token = Jwts
		.builder()
		.setSubject(subject)
		.setIssuer("AKSHAY_SHAHANE")
		.setIssuedAt(new Date(System.currentTimeMillis()))
		.setExpiration(new Date(System.currentTimeMillis()+TimeUnit.MINUTES.toMillis(5)))
		.signWith(SignatureAlgorithm.HS256, Base64.getEncoder().encode(secretKey.getBytes()))
		.compact();
		return token;
	}
	
	//2.read token
	public Claims getClaims(String token) {
		return Jwts.parser().setSigningKey(Base64.getEncoder().encode(secretKey.getBytes())).
				parseClaimsJws(token).getBody();
	}
	
	//3.fetch username from token
	public String getUsername(String token) {
		return getClaims(token).getSubject();
	}
	
	//4.fetch expriration date from token
	public Date getExpDate(String token) {
		return getClaims(token).getExpiration();
	}
	
	//5.check is token expire or not
	public boolean isTokenExpire(String token) {
		return getExpDate(token).before(new Date(System.currentTimeMillis()));
	}
	
	//6.check is token valid or not
	public boolean isValidToken(String token,String username) {
		String dbUsername = getUsername(token);
		return (dbUsername.equalsIgnoreCase(username) && !isTokenExpire(token));
	}
}
