package com.practice.jwt.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.practice.jwt.model.User;
import com.practice.jwt.model.UserRequest;
import com.practice.jwt.model.UserResponse;
import com.practice.jwt.service.IUserService;
import com.practice.jwt.util.JwtUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/user")
@Api(description = "This UserController have all User related functionality")
public class UserController {

	@Autowired
	IUserService userService;

	@Autowired
	JwtUtil jwtUtil;

	@Autowired
	AuthenticationManager authenticationManager;

	@PostMapping("/save")
	@ApiOperation(value = "This method is used to register/create the user")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully registered user"),
			@ApiResponse(code = 401, message = "Unauthorized User"),
			@ApiResponse(code = 403, message = "Forbidden Error") })
	public ResponseEntity<String> createUser(@RequestBody User user) {
		return ResponseEntity.ok(userService.createUser(user));
	}

	@PostMapping("/login")
	@ApiOperation(value = "This method is used to login the application")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully logged in"),
			@ApiResponse(code = 401, message = "Unauthorized user"),
			@ApiResponse(code = 403, message = "Forbidden Error") })
	public ResponseEntity<UserResponse> loginUser(@RequestBody UserRequest userRequest) {
		authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(userRequest.getUsername(), userRequest.getPassword()));
		String token = jwtUtil.generateToken(userRequest.getUsername());
		UserResponse userResponse = new UserResponse();
		userResponse.setToken(token);
		userResponse.setMessage("User logged in Successfully...");
		return ResponseEntity.ok(userResponse);
	}

	@GetMapping("/all")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully fetched all Users"),
			@ApiResponse(code = 401, message = "Unauthorized to access resource"),
			@ApiResponse(code = 403, message = "Forbidden") })
	@ApiOperation(value = "This method will return all authorized users")
	public ResponseEntity<List<User>> getUsers() {
		return ResponseEntity.ok(userService.getUsers());
	}
}
