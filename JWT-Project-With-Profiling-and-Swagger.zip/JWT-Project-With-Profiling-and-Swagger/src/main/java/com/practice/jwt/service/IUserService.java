package com.practice.jwt.service;

import java.util.List;
import java.util.Optional;

import com.practice.jwt.model.User;

public interface IUserService {

	public String createUser(User user);

	public Optional<User> findByUserName(String username);

	public List<User> getUsers();
}
