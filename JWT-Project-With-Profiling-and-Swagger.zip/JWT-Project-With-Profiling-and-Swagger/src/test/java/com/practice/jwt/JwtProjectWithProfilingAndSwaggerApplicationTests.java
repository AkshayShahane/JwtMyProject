package com.practice.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtProjectWithProfilingAndSwaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
