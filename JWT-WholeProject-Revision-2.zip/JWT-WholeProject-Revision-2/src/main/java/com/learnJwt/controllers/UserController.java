package com.learnJwt.controllers;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.learnJwt.model.User;
import com.learnJwt.model.UserRequest;
import com.learnJwt.model.UserResponse;
import com.learnJwt.service.IUserService;
import com.learnJwt.util.JwtUtil;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	IUserService userService;

	@Autowired
	JwtUtil jwtUtil;

	@Autowired
	AuthenticationManager authenticationManager;

	@PostMapping("/save")
	public ResponseEntity<String> createUserRecord(@RequestBody User user) {
		return ResponseEntity.ok(userService.createUserService(user));
	}

	@PostMapping("/login")
	public ResponseEntity<UserResponse> userLogin(@RequestBody UserRequest userRequest) {
		authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(userRequest.getUsername(), userRequest.getPassword()));
		String token = jwtUtil.generateToken(userRequest.getUsername());
		UserResponse responseObj = new UserResponse();
		responseObj.setToken(token);
		responseObj.setMessage("User is logged in Successfully...");
		return ResponseEntity.ok(responseObj);
	}

	@GetMapping("/welcome")
	public ResponseEntity<String> accessData(Principal principal) {
		return ResponseEntity.ok("You have permit to access the Data Mr." + principal.getName());
	}
}
