package com.learnJwt.service.impl;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.learnJwt.model.User;
import com.learnJwt.repositories.UserRepository;
import com.learnJwt.service.IUserService;

@Service
public class UserServiceImpl implements IUserService, UserDetailsService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	BCryptPasswordEncoder bcryptPwdEncoder;

	@Override
	public String createUserService(User user) {
		user.setPassword(bcryptPwdEncoder.encode(user.getPassword()));
		User savedUser = userRepository.save(user);
		return "User is created with userId : " + savedUser.getId();
	}

	@Override
	public Optional<User> findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> opDbUsername = findByUsername(username);
		if(opDbUsername.isEmpty()) {
			throw new UsernameNotFoundException("Record is not found with provided username");
		}
		User user = opDbUsername.get();
		return new org.springframework.security.core.userdetails.User(username,
				user.getPassword(), 
				user.getRoles().stream().map(role->new SimpleGrantedAuthority(role)).collect(Collectors.toList()));
	}


}
