package com.learnJwt.service;

import java.util.Optional;

import com.learnJwt.model.User;

public interface IUserService {

	public String createUserService(User user);
	public Optional<User> findByUsername(String username);
}
