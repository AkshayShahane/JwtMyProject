package com.learnJwt.util;

import java.util.Base64;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {

	@Value("$(app.secret)")
	private String secreteKey;

	// 1.generate token
	public String generateToken(String subject) {
		String token = Jwts.builder().setSubject(subject).setIssuer("akshayShahane")
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(10)))
				.signWith(SignatureAlgorithm.HS256, Base64.getEncoder().encode(secreteKey.getBytes())).compact();
		return token;
	}

	// 2.read token
	public Claims getClaims(String token) {
		return Jwts.parser().setSigningKey(Base64.getEncoder().encode(secreteKey.getBytes())).parseClaimsJws(token)
				.getBody();
	}

	// 3.get username
	public String getUsername(String token) {
		return getClaims(token).getSubject();
	}

	// 4.get expiration name
	public Date expDate(String token) {
		return getClaims(token).getExpiration();
	}

	// 5.check token expire?
	public boolean isTokenExpire(String token) {
		return expDate(token).before(new Date(System.currentTimeMillis()));
	}

	// 6. check token is valid?
	public boolean isValidToken(String username, String token) {
		String tokenUsername = getUsername(username);
		return (tokenUsername.equalsIgnoreCase(username) && !isTokenExpire(token));
	}
}
